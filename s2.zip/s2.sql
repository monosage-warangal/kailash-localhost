-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 06, 2024 at 01:59 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `s2`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `booking_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `passengers` int(11) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `order_status` enum('pending','complete','failed') NOT NULL,
  `departure_date` date DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `hours` time DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`booking_id`, `user_id`, `location`, `passengers`, `start_date`, `order_status`, `departure_date`, `user_email`, `hours`, `created_at`, `updated_at`) VALUES
(1, 2, 'Los Angeles', 4, '2024-06-27', 'complete', '2024-06-28', 'rohit@gmail.com', '00:00:00', '2024-06-26 12:20:50', '2024-07-02 11:26:12'),
(2, 2, 'Chennai', 4, '2024-06-29', 'complete', '2024-06-30', 'rohit@gmail.com', '00:50:00', '2024-06-26 15:49:18', '2024-07-02 11:26:56'),
(21, 2, 'gujarat', 4, '2024-06-27', 'complete', '2024-06-28', 'rohit@gmail.com', '10:00:00', '2024-06-27 05:47:21', '2024-07-02 11:50:31'),
(22, 2, 'warangal', 4, '2024-06-27', 'complete', '2024-06-29', 'rohit@gmail.com', '10:00:00', '2024-06-27 05:48:57', '2024-07-02 11:50:37'),
(23, 2, 'hyderabad', 4, '2024-06-29', 'complete', '2024-06-30', 'rohit@gmail.com', '10:00:00', '2024-06-27 05:50:30', '2024-07-02 11:52:40'),
(24, 2, 'ladakh', 4, '2024-06-27', 'complete', '2024-06-28', 'rohit@gmail.com', '10:00:00', '2024-06-27 08:20:03', '2024-07-02 11:54:10'),
(25, 2, 'gujarat', 4, '2024-06-28', 'complete', '2024-06-29', 'rohit@gmail.com', '10:00:00', '2024-06-27 08:21:01', '2024-07-02 11:59:06'),
(26, 2, 'Chennai', 4, '2024-06-29', 'complete', '2024-06-30', 'rohit@gmail.com', '10:00:00', '2024-06-27 08:21:39', '2024-07-02 13:41:29'),
(27, 2, 'ladakh', 4, '2024-06-28', 'complete', '2024-06-29', 'rohit@gmail.com', '10:00:00', '2024-06-27 08:29:31', '2024-07-02 13:41:38'),
(28, 2, 'gujarat', 4, '2024-06-27', 'complete', '2024-06-29', 'rohit@gmail.com', '10:00:00', '2024-06-27 10:24:18', '2024-07-06 04:58:04'),
(29, 2, 'warangal', 4, '2024-06-28', 'complete', '2024-06-29', 'rohit@gmail.com', '10:00:00', '2024-06-27 10:44:10', '2024-07-06 04:57:48'),
(30, 3, 'gujarat', 4, '2024-06-28', 'complete', '2024-06-29', 'dheeraj@gmail.com', '10:00:00', '2024-06-28 05:34:07', '2024-07-02 11:52:49'),
(31, 2, 'hyderabad', 3, '2024-07-03', 'complete', '2024-07-05', 'rohit@gmail.com', '10:00:00', '2024-07-02 08:50:10', '2024-07-06 05:44:45'),
(32, 2, 'warangal', 4, '2024-07-03', 'complete', '2024-07-10', 'rohit@gmail.com', '10:00:00', '2024-07-02 09:10:07', '2024-07-04 04:33:01'),
(33, 2, 'warangal', 3, '2024-07-04', 'pending', '2024-07-05', 'rohit@gmail.com', '01:00:00', '2024-07-04 04:33:49', '2024-07-04 04:33:49'),
(34, 2, 'Chennai', 4, '2024-07-04', 'pending', '2024-07-05', 'rohit@gmail.com', '04:00:00', '2024-07-04 12:05:36', '2024-07-04 12:05:36');

-- --------------------------------------------------------

--
-- Table structure for table `bookings_transaction`
--

CREATE TABLE `bookings_transaction` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `car_id` int(11) NOT NULL,
  `booking_date` datetime NOT NULL,
  `order_status` enum('pending','complete','failed') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings_transaction`
--

INSERT INTO `bookings_transaction` (`id`, `user_id`, `car_id`, `booking_date`, `order_status`) VALUES
(2, 8, 6, '2024-07-03 07:55:22', 'complete'),
(3, 8, 6, '2024-07-03 07:56:03', 'complete'),
(4, 2, 5, '2024-07-03 08:07:53', 'pending'),
(5, 2, 5, '2024-07-03 08:13:27', 'pending'),
(6, 8, 5, '2024-07-03 08:15:31', 'pending'),
(7, 8, 6, '2024-07-03 08:19:32', 'complete'),
(8, 2, 7, '2024-07-03 08:22:07', 'pending'),
(9, 2, 5, '2024-07-03 08:23:21', 'pending'),
(10, 3, 5, '2024-07-03 08:23:34', 'complete'),
(11, 3, 5, '2024-07-03 08:23:40', 'complete'),
(12, 8, 5, '2024-07-03 08:26:07', 'pending'),
(13, 2, 5, '2024-07-03 08:47:02', 'pending'),
(14, 2, 6, '2024-07-03 08:50:52', 'complete'),
(15, 2, 10, '2024-07-03 09:00:25', 'pending'),
(16, 8, 5, '2024-07-03 09:03:21', 'pending'),
(17, 2, 6, '2024-07-03 10:49:42', 'complete'),
(18, 2, 6, '2024-07-03 10:57:58', 'complete'),
(19, 8, 6, '2024-07-03 11:26:24', 'complete'),
(20, 8, 6, '2024-07-03 11:41:59', 'complete'),
(21, 2, 6, '2024-07-03 11:59:13', 'complete'),
(22, 8, 6, '2024-07-03 13:16:42', 'complete'),
(23, 8, 6, '2024-07-03 13:18:02', 'complete'),
(24, 2, 6, '2024-07-03 13:32:19', 'complete'),
(25, 2, 7, '2024-07-03 13:42:42', 'pending'),
(27, 2, 6, '2024-07-04 06:31:26', 'complete'),
(28, 8, 12, '2024-07-04 07:51:23', 'complete'),
(29, 3, 6, '2024-07-04 08:25:15', 'complete'),
(30, 3, 12, '2024-07-04 08:38:18', 'complete'),
(31, 3, 12, '2024-07-04 08:46:17', 'complete'),
(32, 3, 12, '2024-07-04 08:46:24', 'complete'),
(33, 3, 12, '2024-07-04 08:47:43', 'complete'),
(34, 3, 12, '2024-07-04 08:49:46', 'complete'),
(35, 3, 12, '2024-07-04 08:49:50', 'complete'),
(36, 3, 12, '2024-07-04 08:50:48', 'complete'),
(37, 3, 12, '2024-07-04 08:59:40', 'complete'),
(38, 3, 12, '2024-07-04 09:02:25', 'complete'),
(39, 3, 12, '2024-07-04 09:04:48', 'complete'),
(40, 3, 12, '2024-07-04 09:45:46', 'complete'),
(41, 3, 12, '2024-07-04 09:53:07', 'complete'),
(42, 3, 12, '2024-07-04 09:53:24', 'complete'),
(43, 3, 12, '2024-07-04 09:54:26', 'complete'),
(44, 3, 12, '2024-07-04 09:55:14', 'complete'),
(49, 8, 5, '2024-07-04 10:13:53', 'pending'),
(50, 3, 12, '2024-07-04 10:15:46', 'complete'),
(51, 3, 12, '2024-07-04 10:15:53', 'complete'),
(52, 8, 5, '2024-07-04 10:16:24', 'pending'),
(53, 3, 12, '2024-07-04 08:30:50', 'complete'),
(54, 3, 12, '2024-07-04 08:30:51', 'complete'),
(55, 3, 12, '2024-07-04 08:31:06', 'complete'),
(56, 3, 12, '2024-07-04 08:32:53', 'complete'),
(57, 3, 12, '2024-07-04 10:39:09', 'complete'),
(58, 3, 12, '2024-07-04 10:42:48', 'complete'),
(59, 3, 12, '2024-07-04 10:47:46', 'complete'),
(60, 8, 8, '2024-07-04 10:48:46', 'pending'),
(61, 3, 12, '2024-07-04 10:50:37', 'complete'),
(62, 3, 12, '2024-07-04 10:52:01', 'complete'),
(63, 3, 12, '2024-07-04 10:55:20', 'complete'),
(64, 3, 12, '2024-07-04 10:55:29', 'complete'),
(65, 3, 12, '2024-07-04 10:58:01', 'complete'),
(66, 3, 12, '2024-07-04 10:58:06', 'complete'),
(67, 3, 12, '2024-07-04 10:59:11', 'complete'),
(68, 9, 6, '2024-07-04 11:05:23', 'complete'),
(69, 2, 12, '2024-07-04 11:54:00', 'complete'),
(70, 2, 12, '2024-07-04 11:54:07', 'complete'),
(76, 2, 12, '2024-07-04 12:08:36', 'complete'),
(77, 2, 7, '2024-07-04 12:10:25', 'pending'),
(78, 2, 7, '2024-07-04 12:24:45', 'pending'),
(79, 2, 8, '2024-07-04 12:44:03', 'pending'),
(80, 3, 6, '2024-07-04 13:02:41', 'complete'),
(89, 15, 6, '2024-07-05 19:37:21', 'complete'),
(90, 15, 7, '2024-07-06 06:26:36', 'pending'),
(91, 15, 14, '2024-07-06 07:33:03', 'complete'),
(92, 15, 15, '2024-07-06 08:23:34', 'complete'),
(93, 15, 15, '2024-07-06 08:25:15', 'complete'),
(94, 15, 14, '2024-07-06 08:40:21', 'complete'),
(95, 15, 6, '2024-07-06 11:40:50', 'complete'),
(96, 15, 6, '2024-07-06 12:08:01', 'complete'),
(97, 15, 12, '2024-07-06 12:13:42', 'complete'),
(98, 15, 6, '2024-07-06 13:50:24', 'complete'),
(99, 15, 6, '2024-07-06 13:58:10', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `id` int(11) NOT NULL,
  `car_name` varchar(100) NOT NULL,
  `seating_capacity` int(11) NOT NULL,
  `car_category` varchar(50) NOT NULL,
  `ac_option` decimal(10,2) NOT NULL,
  `non_ac_option` decimal(10,2) NOT NULL,
  `cancellation_policy` varchar(255) NOT NULL,
  `image_path` blob NOT NULL,
  `uploaded_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `location` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`id`, `car_name`, `seating_capacity`, `car_category`, `ac_option`, `non_ac_option`, `cancellation_policy`, `image_path`, `uploaded_by`, `created_at`, `location`) VALUES
(5, 'Hyundai', 4, 'Sedan', 1500.00, 500.00, 'NO', 0x75706c6f6164732f63617231332e6a7067, 8, '2024-06-30 05:24:24', 'Ladakh'),
(6, 'mahindra xuv 600', 5, 'SUV', 2500.00, 2000.00, 'YES', 0x75706c6f6164732f63617232382e6a7067, 8, '2024-06-30 05:59:20', 'Warangal'),
(7, 'Nissan', 2, 'Sedan', 1500.00, 1998.00, 'NO', 0x75706c6f6164732f636172312e6a7067, 8, '2024-07-01 05:30:49', 'Warangal'),
(8, 'Etios', 4, 'Sedan', 2000.00, 1500.00, 'NO', 0x75706c6f6164732f636172332e6a7067, 8, '2024-07-02 13:21:04', 'Mumbai'),
(9, 'Maruti Shift Dzire', 4, 'Compact', 2000.00, 1500.00, 'NO', 0x75706c6f6164732f636172342e6a7067, 8, '2024-07-02 13:23:37', 'Ladakh'),
(10, 'BMW', 4, 'Sedan', 3000.00, 2000.00, 'NO', 0x75706c6f6164732f636172352e6a7067, 8, '2024-07-02 13:26:58', 'Kolkata'),
(12, 'Mahindra Scorpio', 2, 'SUV', 2500.00, 2000.00, 'NO', 0x75706c6f6164732f63617231312e6a7067, 8, '2024-07-02 14:33:17', 'Goa'),
(14, 'Hyndai creta', 3, 'SUV', 3000.00, 2000.00, 'NO', 0x75706c6f6164732f63617231332e6a7067, 8, '2024-07-02 14:53:35', 'Hanmakonda'),
(15, 'Mahendra Scorpio', 4, 'SUV', 3000.00, 2000.00, 'YES', 0x75706c6f6164732f63617231342e6a7067, 8, '2024-07-02 15:39:33', 'Hanmakonda');

-- --------------------------------------------------------

--
-- Table structure for table `temp_users`
--

CREATE TABLE `temp_users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `role` enum('user','admin') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `temp_users`
--

INSERT INTO `temp_users` (`id`, `username`, `email`, `phone_number`, `role`, `created_at`) VALUES
(1, 'rohitrohit', 'rohit@gmail.com', '7896584563', 'user', '2024-06-28 11:56:56');

-- --------------------------------------------------------

--
-- Table structure for table `user1`
--

CREATE TABLE `user1` (
  `id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL DEFAULT 'customer',
  `last_login` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user1`
--

INSERT INTO `user1` (`id`, `firstname`, `lastname`, `username`, `email`, `password`, `role`, `last_login`) VALUES
(1, 'kailash', 'satkuri', 'satkurikailash', 'A@gmail.com', '$2y$10$DyQYmPtKKWmfNpUCDe/an.wOmFoGQgvPBT94S7PR73SYL9/9PP1U.', 'admin', '2024-06-25 17:12:29'),
(2, 'bunny', 'star', 'bunny123', 's@gmail.com', '$2y$10$6iNGZIvLiv52oQ3cOKkOS.uJOjmJ601XEk6uZTNbbvZPeYAfFM6lW', 'customer', NULL),
(3, 'sofia', 'm', 'sofia', 'sofi@gmail.com', '$2y$10$NskAuuVrzbyvLXCQvCp5iuDXvIXdu.Pl/ymrRiCLHY0YsNPWWEMeq', 'admin', '2024-06-25 07:54:34'),
(4, 'upender', 'satkuri', 'satkuriupender', 'satkuriupender@gmail.com', '$2y$10$ov/OPm2F2qAlWU.ueczM5ua3.x3oD0YkxYstk0RSm9gOGLO0BSBv.', 'admin', '2024-06-25 17:12:51');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(12) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `phone_number` varchar(10) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') NOT NULL DEFAULT 'user',
  `profile_pic` blob DEFAULT 'uploads/default.png',
  `otp` varchar(6) DEFAULT NULL,
  `verified` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `firstname`, `lastname`, `phone_number`, `email`, `password`, `role`, `profile_pic`, `otp`, `verified`) VALUES
(2, 'rohitrohit', 'rohi', 'macherla', '7896584563', 'rohit@gmail.com', 'df96220fa161767c5cbb95567855c86b', 'user', 0x75706c6f6164732f70726f66696c655f36363835316663313565376237372e33363030313634392e6a7067, NULL, 0),
(3, 'dheeraj1234', 'dheeraj', 'dheeraj', '7537987897', 'dheeraj@gmail.com', 'df96220fa161767c5cbb95567855c86b', 'user', 0x75706c6f6164732f64656661756c742e706e67, NULL, 0),
(8, 'kailash1234', 'satkuri', 'kailash', '8309740722', 'kailash@gmail.com', 'df96220fa161767c5cbb95567855c86b', 'admin', 0x75706c6f6164732f70726f66696c655f36363766663565303666383338322e33373933323738302e6a7067, NULL, 0),
(9, 'useruser123', 'user', 'user', '8309740722', 'user@gmail.com', 'df96220fa161767c5cbb95567855c86b', 'user', 0x75706c6f6164732f64656661756c742e706e67, NULL, 0),
(10, 'demo1demo1', 'demo1', 'demo1', '8659797878', 'k@g.c', 'df96220fa161767c5cbb95567855c86b', 'user', 0x75706c6f6164732f64656661756c742e706e67, NULL, 0),
(14, 'kailash12345', 'kailash12345', 'kailash12345', '2231321321', 'ksatkuri@gmail.com', 'df96220fa161767c5cbb95567855c86b', 'user', 0x75706c6f6164732f64656661756c742e706e67, NULL, 0),
(15, 'kailash0722', 'kailash0722', 'kailash0722', '9879878988', 'satkurikailash9@gmail.com', 'df96220fa161767c5cbb95567855c86b', 'user', 0x75706c6f6164732f64656661756c742e706e67, NULL, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`booking_id`),
  ADD KEY `fk_user_email` (`user_email`);

--
-- Indexes for table `bookings_transaction`
--
ALTER TABLE `bookings_transaction`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user` (`user_id`),
  ADD KEY `fk_car` (`car_id`);

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_uploaded_by` (`uploaded_by`);

--
-- Indexes for table `temp_users`
--
ALTER TABLE `temp_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user1`
--
ALTER TABLE `user1`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `bookings_transaction`
--
ALTER TABLE `bookings_transaction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;

--
-- AUTO_INCREMENT for table `cars`
--
ALTER TABLE `cars`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `temp_users`
--
ALTER TABLE `temp_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user1`
--
ALTER TABLE `user1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `fk_user_email` FOREIGN KEY (`user_email`) REFERENCES `users` (`email`);

--
-- Constraints for table `bookings_transaction`
--
ALTER TABLE `bookings_transaction`
  ADD CONSTRAINT `fk_car` FOREIGN KEY (`car_id`) REFERENCES `cars` (`id`),
  ADD CONSTRAINT `fk_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `cars`
--
ALTER TABLE `cars`
  ADD CONSTRAINT `fk_uploaded_by` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
